/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kesalahanvariable;

/**
 *
 * @author SEKAR MAULIYAH
 */
public class KesalahanVariable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //DEKLARASI VARIABLE YANG BENAR
        Boolean gameOver = false;
        int students = 50, classes =3;
        double sales_tax;
        short number1;
        
        //DEKLARASI VARIABLE YANG SALAH
        int 2beOrNot2be;
        float price index;
        double lastYear'sPrice;
        long class;
        
        
    }
    
}
